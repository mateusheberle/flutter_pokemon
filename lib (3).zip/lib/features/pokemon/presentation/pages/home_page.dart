import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/pokemon_controller.dart';
import '../../domain/entities/pokemon_entity.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pokédex'), centerTitle: true),
      body: Consumer<PokemonController>(
        builder: (_, controller, __) {
          // 🔄 Loading inicial
          if (controller.isLoading && controller.pokemons.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }

          // ❌ Erro
          if (controller.error != null && controller.pokemons.isEmpty) {
            return Center(
              child: Text(
                controller.error!,
                style: const TextStyle(color: Colors.red),
              ),
            );
          }

          // ✅ Lista com scroll infinito
          return NotificationListener<ScrollNotification>(
            onNotification: (scroll) {
              if (scroll.metrics.pixels >=
                  scroll.metrics.maxScrollExtent - 200) {
                controller.loadPokemons();
              }
              return false;
            },
            child: ListView.builder(
              itemCount:
                  controller.pokemons.length + (controller.isLoading ? 1 : 0),
              itemBuilder: (context, index) {
                if (index >= controller.pokemons.length) {
                  // loading no final da lista
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: Center(
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                  );
                }

                final PokemonEntity pokemon = controller.pokemons[index];

                return ListTile(
                  leading: Image.network(
                    pokemon.imageUrl,
                    width: 56,
                    height: 56,
                    fit: BoxFit.cover,
                  ),
                  title: Text(
                    pokemon.name,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  onTap: () {
                    // 👉 Navegação para detalhes (passo seguinte)
                    Navigator.pushNamed(
                      context,
                      '/pokemon-detail',
                      arguments: pokemon.id,
                    );
                  },
                );
              },
            ),
          );
        },
      ),
    );
  }
}
