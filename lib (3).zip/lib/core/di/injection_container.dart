import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';

import '../../features/pokemon/domain/usecases/get_pokemons_usecase.dart';
import '../../features/pokemon/domain/usecases/get_pokemon_detail_usecase.dart';
import '../../features/pokemon/domain/repositories/pokemon_repository.dart';

import '../../features/pokemon/data/datasources/pokemon_remote_datasource.dart';
import '../../features/pokemon/data/datasources/pokemon_remote_datasource_impl.dart';
import '../../features/pokemon/data/repositories/pokemon_repository_impl.dart';

import '../../features/pokemon/presentation/state/pokemon_controller.dart';

final GetIt sl = GetIt.instance;

Future<void> setupInjection() async {
  // 🔌 External
  sl.registerLazySingleton<Dio>(() {
    return Dio(
      BaseOptions(
        baseUrl: 'https://pokeapi.co/api/v2/',
        connectTimeout: const Duration(seconds: 10),
        receiveTimeout: const Duration(seconds: 10),
      ),
    );
  });

  // 📡 DataSources
  sl.registerLazySingleton<PokemonRemoteDataSource>(
    () => PokemonRemoteDataSourceImpl(sl()),
  );

  // 📦 Repositories
  sl.registerLazySingleton<PokemonRepository>(
    () => PokemonRepositoryImpl(sl()),
  );

  // 🧠 UseCases
  sl.registerLazySingleton(() => GetPokemonsUseCase(sl()));

  sl.registerLazySingleton(() => GetPokemonDetailUseCase(sl()));

  // 🎮 Controllers
  sl.registerFactory(() => PokemonController(sl()));
}

void main() {
  late GetPokemonsUseCase usecase;
  late MockPokemonRepository repository;

  setUp(() {
    repository = MockPokemonRepository();
    usecase = GetPokemonsUseCase(repository);
  });

  test('deve retornar uma lista de Pokémon do repositório', () async {
    // arrange
    final pokemons = [
      PokemonEntity(
        id: 1,
        name: 'bulbasaur',
        imageUrl: 'url',
        types: ['grass', 'poison'],
        height: 7,
        weight: 69,
      ),
    ];

    when(
      () => repository.getPokemons(limit: 20, offset: 0),
    ).thenAnswer((_) async => pokemons);

    // act
    final result = await usecase(limit: 20, offset: 0);

    // assert
    expect(result, equals(pokemons));
    verify(() => repository.getPokemons(limit: 20, offset: 0)).called(1);
    verifyNoMoreInteractions(repository);
  });
}
