import 'package:flutter/material.dart';

import '../../../../core/usecase/app_strings.dart';
import '../widgets/app_style.dart';
import 'home_page.dart';

/// Page for selecting Pokemon generations
class GenerationsPage extends StatelessWidget {
  const GenerationsPage({super.key});

  void _selecionarGeracao(BuildContext context, int geracao) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          AppStrings.generationSelected(geracao),
          style: const TextStyle(color: AppStyle.primaryDark),
        ),
        backgroundColor: AppStyle.backgroundDark,
        duration: const Duration(seconds: 1),
      ),
    );
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            HomePage(title: AppStrings.appTitle, generation: geracao),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppStyle.backgroundDark,
      appBar: AppBar(
        title: Text(
          AppStrings.generationsTitle,
          style: TextStyle(
            color: AppStyle.mainColor,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        backgroundColor: Colors.transparent,
        centerTitle: true,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: List.generate(3, (index) {
            final geracao = index + 1;
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: SizedBox(
                width: double.infinity,
                height: 100,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(24),
                      side: const BorderSide(color: AppStyle.primaryDark),
                    ),
                    backgroundColor: AppStyle.surfaceDark,
                    foregroundColor: AppStyle.mainColor,
                  ),
                  onPressed: () => _selecionarGeracao(context, geracao),
                  child: Text(
                    '$geracaoª ${AppStrings.generation}',
                    style: TextStyle(fontSize: 24, color: AppStyle.primaryDark),
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
