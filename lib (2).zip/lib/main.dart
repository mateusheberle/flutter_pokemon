import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/usecase/app_strings.dart';
import 'features/pokemon/presentation/pages/generations_page.dart';
import 'features/pokemon/presentation/pages/home_page.dart';
import 'features/pokemon/presentation/state/pokemon_controller.dart';
import 'features/pokemon/presentation/widgets/app_style.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => PokemonController(sl())..loadPokemons(),
          child: const HomePage(),
        ),
      ],
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppStrings.appTitle,
      theme: AppStyle.theme,
      initialRoute: '/',
      routes: <String, WidgetBuilder>{
        '/': (BuildContext context) => const GenerationsPage(),
        '/homePage': (BuildContext context) =>
            const HomePage(title: AppStrings.appTitle, generation: 1),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}
